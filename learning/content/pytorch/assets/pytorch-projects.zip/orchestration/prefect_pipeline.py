# file: orchestration/prefect_pipeline.py
import argparse
from pathlib import Path
from prefect import flow, task
from prefect.runtime import flow_run
from prefect.schedules import Cron
from .common import train_candidate, evaluate_candidate, stage_for_review

@task(retries=2, retry_delay_seconds=5)
def train_task(kind, run_id):
    return train_candidate(kind, Path("candidate-runs") / run_id)

@task
def evaluate_task(folder):
    return evaluate_candidate(folder)

@task
def stage_task(report):
    return stage_for_review(report)

@flow(name="model-candidate-workflow", log_prints=True)
def candidate_workflow(kind="vision"):
    run_id = str(flow_run.id)
    artifact = train_task(kind, run_id)
    return stage_task(evaluate_task(artifact))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("kind", choices=["vision", "text"])
    parser.add_argument("--schedule", action="store_true")
    args = parser.parse_args()
    if args.schedule:
        candidate_workflow.serve(name=f"{args.kind}-candidates", parameters={"kind": args.kind},
            schedule=Cron("0 3 * * *", timezone="UTC"))
    else:
        candidate_workflow(kind=args.kind)
