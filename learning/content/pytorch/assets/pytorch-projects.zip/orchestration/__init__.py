# file: orchestration/__init__.py
"""Teaching workflows; framework integrations require separate installation."""
