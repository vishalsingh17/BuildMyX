# file: orchestration/common.py
import hashlib
import json
from pathlib import Path

def weight_hash(folder):
    return hashlib.sha256((Path(folder) / "weights.pt").read_bytes()).hexdigest()

def train_candidate(kind, run_folder):
    if kind not in ("vision", "text"):
        raise ValueError("Unknown project kind")
    folder = Path(run_folder) / kind
    complete = folder / "complete.json"
    if complete.is_file():
        marker = json.loads(complete.read_text(encoding="utf-8"))
        if marker["sha256"] != weight_hash(folder):
            raise ValueError("Completed artifact changed")
        return str(folder)
    if kind == "vision":
        from vision_project.train import run_training
    else:
        from text_project.train import run_training
    run_training(str(folder))
    complete.write_text(json.dumps({"kind": kind, "sha256": weight_hash(folder)}), encoding="utf-8")
    return str(folder)

def evaluate_candidate(folder):
    folder = Path(folder)
    history = json.loads((folder / "history.json").read_text(encoding="utf-8"))
    selected = min(history, key=lambda row: row["loss"])
    return {"artifact": str(folder), "sha256": weight_hash(folder),
            "validation_loss": selected["loss"], "validation_accuracy": selected["accuracy"]}

def stage_for_review(report):
    eligible = report["validation_loss"] < 2.0
    return {**report, "status": "awaiting-review" if eligible else "rejected"}
