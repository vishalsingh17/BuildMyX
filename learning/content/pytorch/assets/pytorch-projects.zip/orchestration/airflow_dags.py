# file: orchestration/airflow_dags.py
from datetime import timedelta
from pathlib import Path
import hashlib
import pendulum
from airflow.sdk import dag, task, get_current_context
from orchestration.common import train_candidate, evaluate_candidate, stage_for_review

@task(retries=2, retry_delay=timedelta(seconds=30))
def train_task(kind):
    context = get_current_context()
    run_key = hashlib.sha256(context["run_id"].encode()).hexdigest()[:20]
    return train_candidate(kind, Path("candidate-runs") / run_key)

@task
def evaluate_task(folder):
    return evaluate_candidate(folder)

@task
def stage_task(report):
    return stage_for_review(report)

def make_dag(kind, schedule):
    @dag(dag_id=f"buildmyx_{kind}_candidates", schedule=schedule,
         start_date=pendulum.datetime(2026, 1, 1, tz="UTC"),
         catchup=False, max_active_runs=1)
    def candidate_dag():
        artifact = train_task(kind)
        stage_task(evaluate_task(artifact))
    return candidate_dag()

vision_candidates = make_dag("vision", "0 3 * * *")
text_candidates = make_dag("text", "0 4 * * *")
