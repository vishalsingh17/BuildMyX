# file: text_project/serve.py
import json
from pathlib import Path
import torch
from fastapi import FastAPI
from pydantic import BaseModel, Field, field_validator
from torch.nn.utils.rnn import pad_sequence
from .data import encode
from .model import SentimentLSTM

def load_artifact(folder):
    folder = Path(folder)
    metadata = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
    vocabulary = metadata["vocabulary"]
    if metadata.get("schema_version") != 1 or metadata.get("tokenizer") != "casefold-whitespace-v1":
        raise ValueError("Unsupported text artifact")
    if vocabulary.get("<pad>") != 0 or vocabulary.get("<unk>") != 1:
        raise ValueError("Incorrect special token IDs")
    if sorted(vocabulary.values()) != list(range(len(vocabulary))):
        raise ValueError("Vocabulary IDs must be unique and contiguous")
    model = SentimentLSTM(len(vocabulary), metadata["embedding_dim"], metadata["hidden_dim"])
    model.load_state_dict(torch.load(folder / "weights.pt", map_location="cpu", weights_only=True))
    return model.eval(), metadata

def predict_texts(model, metadata, texts):
    if not 1 <= len(texts) <= 16 or any(not t.strip() or len(t) > 2000 for t in texts):
        raise ValueError("Expected 1–16 non-empty texts of at most 2000 characters")
    sequences = [encode(text, metadata["vocabulary"], metadata["max_tokens"]) for text in texts]
    lengths = torch.tensor([len(x) for x in sequences])
    tokens = pad_sequence(sequences, batch_first=True)
    with torch.inference_mode():
        return model(tokens, lengths).argmax(1).tolist()

class TextRequest(BaseModel):
    texts: list[str] = Field(min_length=1, max_length=16)

    @field_validator("texts")
    @classmethod
    def validate_texts(cls, texts):
        if any(not text.strip() or len(text) > 2000 for text in texts):
            raise ValueError("Text is empty or too long")
        return texts

def create_app(folder):
    model, metadata = load_artifact(folder)
    app = FastAPI(title="Local toy sentiment classifier")
    @app.post("/predict")
    def predict(request: TextRequest):
        return {"model_version": metadata["model_version"],
                "classes": predict_texts(model, metadata, request.texts)}
    return app
