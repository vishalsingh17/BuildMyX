# file: text_project/__init__.py
"""Original BuildMyX synthetic text teaching project."""
