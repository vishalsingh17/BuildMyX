# file: text_project/data.py
import csv
import torch
from torch.nn.utils.rnn import pad_sequence

TRAIN_ROWS = [("clear useful guide", 1), ("really helpful guide", 1),
    ("useful examples", 1), ("broken confusing guide", 0),
    ("really confusing examples", 0), ("unhelpful lesson", 0)]
VALIDATION_ROWS = [("helpful examples", 1), ("confusing guide", 0)]

def tokenize(text):
    tokens = text.casefold().split()
    if not tokens:
        raise ValueError("Text must contain a token")
    return tokens

def build_vocab(rows):
    vocabulary = {"<pad>": 0, "<unk>": 1}
    for token in sorted({token for text, _ in rows for token in tokenize(text)}):
        vocabulary[token] = len(vocabulary)
    return vocabulary

def encode(text, vocabulary, max_tokens=64):
    return torch.tensor([vocabulary.get(token, 1) for token in tokenize(text)[:max_tokens]], dtype=torch.long)

def collate(rows, vocabulary):
    texts, labels = zip(*rows)
    sequences = [encode(text, vocabulary) for text in texts]
    lengths = torch.tensor([len(x) for x in sequences])
    return pad_sequence(sequences, batch_first=True), lengths, torch.tensor(labels, dtype=torch.long)

def read_csv_rows(path):
    with open(path, encoding="utf-8", newline="") as file:
        reader = csv.DictReader(file)
        if reader.fieldnames != ["text", "label"]:
            raise ValueError("Expected text,label CSV columns")
        rows = [(row["text"], int(row["label"])) for row in reader]
    if not rows or any(label not in (0, 1) or not text.strip() for text, label in rows):
        raise ValueError("Expected non-empty text and binary class IDs")
    return rows
