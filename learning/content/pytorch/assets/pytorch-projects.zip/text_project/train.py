# file: text_project/train.py
import copy
import json
from pathlib import Path
from functools import partial
import torch
from torch import nn
from torch.utils.data import DataLoader
from .data import TRAIN_ROWS, VALIDATION_ROWS, build_vocab, collate
from .model import SentimentLSTM

def evaluate(model, loader):
    model.eval()
    total, correct, count = 0.0, 0, 0
    with torch.inference_mode():
        for tokens, lengths, targets in loader:
            logits = model(tokens, lengths)
            total += nn.functional.cross_entropy(logits, targets).item() * len(targets)
            correct += logits.argmax(1).eq(targets).sum().item()
            count += len(targets)
    if not count:
        raise ValueError("Empty evaluation loader")
    return {"loss": total / count, "accuracy": correct / count, "count": count}

def fit(model, training, validation, epochs=25, lr=0.03):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    best, state, history = float("inf"), None, []
    for epoch in range(epochs):
        model.train()
        for tokens, lengths, targets in training:
            optimizer.zero_grad(set_to_none=True)
            loss = nn.functional.cross_entropy(model(tokens, lengths), targets)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
        metrics = evaluate(model, validation)
        history.append({"epoch": epoch, **metrics})
        if metrics["loss"] < best:
            best, state = metrics["loss"], copy.deepcopy(model.state_dict())
    if state is None:
        raise ValueError("Training needs a valid epoch")
    model.load_state_dict(state)
    return history

def run_training(destination="text-artifact"):
    torch.manual_seed(83)
    vocabulary = build_vocab(TRAIN_ROWS)
    collator = partial(collate, vocabulary=vocabulary)
    training = DataLoader(TRAIN_ROWS, batch_size=3, shuffle=True,
        generator=torch.Generator().manual_seed(83), collate_fn=collator)
    validation = DataLoader(VALIDATION_ROWS, batch_size=2, collate_fn=collator)
    model = SentimentLSTM(len(vocabulary))
    history = fit(model, training, validation)
    folder = Path(destination)
    folder.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), folder / "weights.pt")
    metadata = {"schema_version": 1, "model_version": "toy-sentiment-v1", "vocabulary": vocabulary,
        "embedding_dim": 8, "hidden_dim": 8, "max_tokens": 64,
        "tokenizer": "casefold-whitespace-v1", "classes": ["negative", "positive"]}
    (folder / "metadata.json").write_text(json.dumps(metadata), encoding="utf-8")
    (folder / "history.json").write_text(json.dumps(history), encoding="utf-8")
    return model, vocabulary, history

if __name__ == "__main__":
    run_training()
