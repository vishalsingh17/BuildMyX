# BuildMyX PyTorch teaching projects

These original projects use small synthetic fixtures. They do not establish
CIFAR-10 or IMDb benchmark performance. Python 3.12+ is required.

Create and activate a virtual environment, then install requirements-cpu.txt.
The explicit +cpu pins apply to Linux x86-64; other platforms use the matching
public torch version. See the official PyTorch installation selector if needed.

From this folder:

    python -m vision_project.train
    python -m text_project.train

These create local vision-artifact/ and text-artifact/ directories. They do not
start a public server. The course shows evaluation and in-process FastAPI tests.
Each serve.py exposes create_app(folder) for a separately configured server.

    python -c "from orchestration.common import train_candidate; print(train_candidate('vision', 'candidate-run-1'))"

The orchestration/prefect_pipeline.py and airflow_dags.py files are OPTIONAL
integration recipes, syntax-checked by the course tooling. They require a
separate Prefect 3 or Airflow 3 installation and runtime configuration. Running
a Prefect recipe starts its configured flow runtime; --schedule creates a served
deployment/schedule. An Airflow recipe belongs in its configured DAG environment.
No model promotion or notification integration is implemented by these recipes.

Read the lessons and complete source coverage at BuildMyX Learn:
https://build-my-x.vercel.app/learn/pytorch/

The source coverage checklist was inspired by the supplied Aman.ai PyTorch
primer, https://aman.ai/primers/pytorch/. Code and fixtures here are original.
