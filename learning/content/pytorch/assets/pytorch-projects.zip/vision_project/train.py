# file: vision_project/train.py
import copy
import json
from pathlib import Path
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader
from .data import ColorSamples
from .model import ColorCNN
from .evaluate import evaluate

def fit(model, training, validation, epochs=18, lr=0.15):
    optimizer = torch.optim.SGD(model.parameters(), lr=lr)
    best, state, history = float("inf"), None, []
    for epoch in range(epochs):
        model.train()
        for images, targets in training:
            optimizer.zero_grad(set_to_none=True)
            loss = F.cross_entropy(model(images), targets)
            loss.backward()
            optimizer.step()
        metrics = evaluate(model, validation)
        history.append({"epoch": epoch, **metrics})
        if metrics["loss"] < best:
            best, state = metrics["loss"], copy.deepcopy(model.state_dict())
    if state is None:
        raise ValueError("Training needs at least one valid epoch")
    model.load_state_dict(state)
    return history

def run_training(destination="vision-artifact"):
    torch.manual_seed(71)
    training = DataLoader(ColorSamples(seed=70), batch_size=8, shuffle=True,
        generator=torch.Generator().manual_seed(71))
    validation = DataLoader(ColorSamples(repeats=2, seed=72), batch_size=6)
    model = ColorCNN()
    history = fit(model, training, validation)
    folder = Path(destination)
    folder.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), folder / "weights.pt")
    metadata = {"schema_version": 1, "model_version": "colors-v1",
        "classes": ["red", "green", "blue"], "input": "float32-NCHW-RGB-8x8-[0,1]"}
    (folder / "metadata.json").write_text(json.dumps(metadata), encoding="utf-8")
    (folder / "history.json").write_text(json.dumps(history), encoding="utf-8")
    return model, history

if __name__ == "__main__":
    run_training()
