# file: vision_project/model.py
from torch import nn

class ColorCNN(nn.Module):
    def __init__(self, classes=3):
        super().__init__()
        self.layers = nn.Sequential(nn.Conv2d(3, 6, 1), nn.ReLU(),
            nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(6, classes))

    def forward(self, images):
        return self.layers(images)
