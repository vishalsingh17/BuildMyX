# file: vision_project/__init__.py
"""Original BuildMyX synthetic vision teaching project."""
