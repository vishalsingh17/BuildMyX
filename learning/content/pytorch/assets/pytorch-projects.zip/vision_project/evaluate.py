# file: vision_project/evaluate.py
import torch
from torch.nn import functional as F

def evaluate(model, loader):
    model.eval()
    loss_sum, correct, count = 0.0, 0, 0
    with torch.inference_mode():
        for images, targets in loader:
            logits = model(images)
            loss_sum += F.cross_entropy(logits, targets).item() * len(targets)
            correct += logits.argmax(1).eq(targets).sum().item()
            count += len(targets)
    if count == 0:
        raise ValueError("Empty evaluation dataset")
    return {"loss": loss_sum / count, "accuracy": correct / count, "count": count}
