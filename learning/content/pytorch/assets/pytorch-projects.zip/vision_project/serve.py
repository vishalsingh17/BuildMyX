# file: vision_project/serve.py
import json
from pathlib import Path
import torch
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from .model import ColorCNN

def load_artifact(folder):
    folder = Path(folder)
    metadata = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
    if metadata.get("schema_version") != 1 or metadata.get("classes") != ["red", "green", "blue"]:
        raise ValueError("Unsupported vision artifact")
    model = ColorCNN()
    model.load_state_dict(torch.load(folder / "weights.pt", map_location="cpu", weights_only=True))
    return model.eval(), metadata

def predict_images(model, images):
    images = torch.as_tensor(images, dtype=torch.float32)
    if images.ndim != 4 or tuple(images.shape[1:]) != (3, 8, 8) or not 1 <= len(images) <= 16:
        raise ValueError("Expected 1–16 NCHW RGB 8x8 images")
    if not torch.isfinite(images).all() or images.min() < 0 or images.max() > 1:
        raise ValueError("Expected finite image values in [0,1]")
    with torch.inference_mode():
        return model(images).argmax(1).tolist()

class ImagesRequest(BaseModel):
    images: list = Field(min_length=1, max_length=16)

def create_app(folder):
    model, metadata = load_artifact(folder)
    app = FastAPI(title="Local color-pattern classifier")
    @app.post("/predict")
    def predict(request: ImagesRequest):
        try:
            classes = predict_images(model, request.images)
        except (ValueError, TypeError) as error:
            raise HTTPException(status_code=422, detail=str(error)) from error
        return {"model_version": metadata["model_version"], "classes": classes}
    return app
