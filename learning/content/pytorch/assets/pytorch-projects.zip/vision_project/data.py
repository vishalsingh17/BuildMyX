# file: vision_project/data.py
import torch
from torch.utils.data import Dataset

class ColorSamples(Dataset):
    def __init__(self, repeats=8, seed=70):
        generator = torch.Generator().manual_seed(seed)
        self.labels = torch.arange(3).repeat(repeats)
        self.images = torch.rand(len(self.labels), 3, 8, 8, generator=generator) * 0.05
        for index, label in enumerate(self.labels):
            self.images[index, label] += 0.8

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, index):
        return self.images[index], self.labels[index]
