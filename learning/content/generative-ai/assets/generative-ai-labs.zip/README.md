# BuildMyX Generative AI labs

Use Python 3.12 or newer. The core examples use only the standard library.
Run a chapter program in a fresh process, for example:

    python3 labs/05-attention.py
    python3 capstone_assistant.py
    python3 -m unittest test_capstone.py

The 32 chapter programs contain their documented calculations and assertions.
The capstone is a deterministic extractive prototype with fictional workshop
records. It demonstrates retrieval, evidence references, abstention, response
validation and a bounded run. A hosted or local language-model adapter is a
separate extension requiring its own integration and evaluation.

The `role` argument simulates a trusted caller for an exercise. Real applications
must derive access scope from authoritative authentication/authorization;
untrusted input cannot confer staff permission.

These scripts do not call model services, send notifications, control hardware
or establish production model quality. Tests cover only the teaching fixtures.

Course: https://build-my-x.vercel.app/learn/generative-ai/
Source reading: https://build-my-x.vercel.app/learn/generative-ai/sources/

The explanations and programs are original BuildMyX teaching material.
The linked primers and research papers remain the work of their authors.
The archive contains no source-article copies, model weights or API keys.
