# BuildMyX Generative AI: Condition image and video generation
# Original CPU teaching example; run with Python 3.12+.

unconditional = [0.0, 1.0]
conditional = [2.0, 3.0]

def guided(scale):
    return [u + scale * (c - u) for u, c in zip(unconditional, conditional)]

assert guided(0.0) == unconditional
assert guided(1.0) == conditional
assert guided(2.0) == [4.0, 5.0]

