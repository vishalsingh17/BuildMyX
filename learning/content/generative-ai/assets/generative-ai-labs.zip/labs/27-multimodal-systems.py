# BuildMyX Generative AI: Build and evaluate a multimodal system
# Original CPU teaching example; run with Python 3.12+.

frames = [
    {"id": "frame-0", "time_s": 0.0},
    {"id": "frame-1", "time_s": 0.5},
    {"id": "frame-2", "time_s": 1.0},
]
start, end = 0.4, 0.8
selected = [frame for frame in frames if start <= frame["time_s"] <= end]
assert [frame["id"] for frame in selected] == ["frame-1"]
patches_per_frame, text_tokens = 256, 200
assert len(frames) * patches_per_frame + text_tokens == 968


width, height = 640, 480
box = {"x1": 20, "y1": 30, "x2": 210, "y2": 160}
assert 0 <= box["x1"] < box["x2"] <= width
assert 0 <= box["y1"] < box["y2"] <= height

