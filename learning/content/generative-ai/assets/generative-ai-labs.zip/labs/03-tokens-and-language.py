# BuildMyX Generative AI: Tokens and language modeling
# Original CPU teaching example; run with Python 3.12+.

from collections import Counter, defaultdict

sentences = ["learn python today", "learn python slowly", "learn data today"]
counts = defaultdict(Counter)
for sentence in sentences:
    words = ["<start>", *sentence.split(), "<end>"]
    for left, right in zip(words, words[1:]):
        counts[left][right] += 1

following = counts["learn"]
total = sum(following.values())
assert following["python"] / total == 2 / 3
assert following["data"] / total == 1 / 3
assert max(counts["python"], key=counts["python"].get) in {"today", "slowly"}


tokens = [10, 20, 30, 99]
inputs, targets = tokens[:-1], tokens[1:]
assert list(zip(inputs, targets)) == [(10, 20), (20, 30), (30, 99)]

