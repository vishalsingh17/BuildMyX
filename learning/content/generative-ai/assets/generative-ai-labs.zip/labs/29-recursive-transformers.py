# BuildMyX Generative AI: Understand recursive computation
# Original CPU teaching example; run with Python 3.12+.

target, state = 1.0, 0.0
errors = []
for _ in range(5):
    state = 0.5 * state + 0.5 * target
    errors.append(abs(target - state))
assert all(later < earlier for earlier, later in zip(errors, errors[1:]))
assert errors[-1] == 0.03125

