# BuildMyX Generative AI: Connect perception, prediction and action
# Original CPU teaching example; run with Python 3.12+.

# A one-dimensional software-only illustration of a control boundary.
def limit_action(proposed, previous, stop, maximum_speed=0.2, maximum_change=0.05):
    if stop:
        return 0.0
    if abs(previous) > maximum_speed:
        raise ValueError("The prior state is outside the toy operating envelope")
    bounded = max(-maximum_speed, min(maximum_speed, proposed))
    return max(previous - maximum_change, min(previous + maximum_change, bounded))

assert limit_action(1.0, 0.0, False) == 0.05
assert limit_action(1.0, 0.1, True) == 0.0
assert -0.2 <= limit_action(-1.0, 0.0, False) <= 0.2

