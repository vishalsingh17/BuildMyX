# BuildMyX Generative AI: Capstone: explain, test and improve your assistant
# Original CPU teaching example; run with Python 3.12+.

baseline_cases = [True, True, False, True, False]
candidate_cases = [True, True, True, True, False]
improved = sum(candidate_cases) - sum(baseline_cases)
regressions = [index for index, (old, new) in enumerate(zip(baseline_cases, candidate_cases)) if old and not new]
assert improved == 1 and regressions == []

