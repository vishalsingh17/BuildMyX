# BuildMyX Generative AI: Adapt a model with parameter-efficient tuning
# Original CPU teaching example; run with Python 3.12+.

W = [[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]]
A = [[0.2, -0.1]]       # rank 1, input dimension 2
B = [[0.0], [0.0], [0.0]]
rank, alpha = 1, 2
scale = alpha / rank
assert all(scale * B[row][0] * A[0][column] == 0 for row in range(3) for column in range(2))
# A hypothetical learned B, supplied here to inspect the resulting update.
B = [[0.3], [-0.2], [0.1]]
merged = [[W[row][column] + scale * B[row][0] * A[0][column] for column in range(2)] for row in range(3)]
assert merged[0][0] > W[0][0]
input_size, output_size, rank = 1024, 1024, 8
assert rank * (input_size + output_size) < input_size * output_size

