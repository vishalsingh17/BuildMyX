# BuildMyX Generative AI: The math behind a prediction
# Original CPU teaching example; run with Python 3.12+.

import math

def softmax(scores):
    maximum = max(scores)
    values = [math.exp(score - maximum) for score in scores]
    total = sum(values)
    return [value / total for value in values]

probabilities = softmax([2.0, 1.0, 0.0])
assert math.isclose(sum(probabilities), 1.0)
assert probabilities[0] > probabilities[1] > probabilities[2]
assert softmax([1002.0, 1001.0, 1000.0]) == probabilities


# One logistic-model update on one positive synthetic example.
w, x, target, learning_rate = 0.0, 2.0, 1.0, 0.1
sigmoid = lambda value: 1 / (1 + math.exp(-value))
before = sigmoid(w * x)
gradient = (before - target) * x
w -= learning_rate * gradient
after = sigmoid(w * x)
assert -math.log(after) < -math.log(before)

