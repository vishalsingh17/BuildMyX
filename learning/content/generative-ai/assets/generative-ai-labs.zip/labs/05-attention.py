# BuildMyX Generative AI: Understand attention, one weighted sum at a time
# Original CPU teaching example; run with Python 3.12+.

import math

def dot(left, right):
    return sum(x*y for x, y in zip(left, right))

def weights(scores):
    maximum = max(scores)
    values = [math.exp(score - maximum) for score in scores]
    return [value / sum(values) for value in values]

query = [1.0, 0.0]
keys = [[1.0, 0.0], [0.0, 1.0], [2.0, 0.0]]
values = [[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]]
scores = [dot(query, key) / math.sqrt(2) for key in keys]
attention = weights(scores)
output = [sum(weight * value[column] for weight, value in zip(attention, values)) for column in range(2)]
assert math.isclose(sum(attention), 1.0)
assert attention[2] > attention[0] > attention[1]
assert len(output) == 2


query_position = 1
masked_scores = [score if index <= query_position else -math.inf for index, score in enumerate(scores)]
causal_weights = weights(masked_scores)
assert causal_weights[2] == 0.0
assert math.isclose(sum(causal_weights), 1.0)

