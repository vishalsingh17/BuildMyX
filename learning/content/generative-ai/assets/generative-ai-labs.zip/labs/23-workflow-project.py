# BuildMyX Generative AI: Project: an assistant workflow you can replay
# Original CPU teaching example; run with Python 3.12+.

import json
from dataclasses import dataclass, asdict

@dataclass
class Run:
    request_id: str
    stage: str = "retrieve"
    evidence: tuple = ()
    answer: str = ""
    verified: bool = False
    budget: int = 3

run = Run("teaching-request-1")
while run.stage not in {"completed", "needs_information", "budget_exhausted"}:
    if run.budget <= 0:
        run.stage = "budget_exhausted"
        break
    run.budget -= 1
    if run.stage == "retrieve":
        run.evidence = ("python-1",)
        run.stage = "respond" if run.evidence else "needs_information"
    elif run.stage == "respond":
        run.answer = "The fictional Python workshop covers functions."
        run.stage = "verify"
    elif run.stage == "verify":
        run.verified = bool(run.answer and "python-1" in run.evidence)
        run.stage = "completed" if run.verified else "needs_information"
    else:
        raise ValueError("Unsupported state")
checkpoint = json.loads(json.dumps(asdict(run)))
assert checkpoint["stage"] == "completed" and checkpoint["verified"] is True
assert checkpoint["budget"] == 0


accepted = {}

def record_acceptance(request_id, value):
    if request_id in accepted:
        return accepted[request_id]
    accepted[request_id] = value
    return value

first = record_acceptance(run.request_id, checkpoint)
second = record_acceptance(run.request_id, {"stage": "different"})
assert first == second and len(accepted) == 1

