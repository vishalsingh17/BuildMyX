# BuildMyX Generative AI: Measure quality before changing the system
# Original CPU teaching example; run with Python 3.12+.

import math

relevant = {"python-1", "schedule-1"}
ranking = ["other-1", "python-1", "schedule-1"]
recall_at_2 = len(set(ranking[:2]) & relevant) / len(relevant)
first_relevant = next(index for index, value in enumerate(ranking, 1) if value in relevant)
reciprocal_rank = 1 / first_relevant
assert recall_at_2 == 0.5
assert reciprocal_rank == 0.5

def dcg(grades):
    return sum((2**grade - 1) / math.log2(rank + 1) for rank, grade in enumerate(grades, 1))
actual = [1, 3, 0]
ideal = sorted(actual, reverse=True)
assert 0 < dcg(actual) / dcg(ideal) < 1

