# BuildMyX Generative AI: Operate and improve a GenAI application
# Original CPU teaching example; run with Python 3.12+.

usage = {"input_tokens": 1200, "output_tokens": 250, "retrieval_ms": 30, "generation_ms": 700}
fictional_input_units, fictional_output_units = 1, 3
cost_units = usage["input_tokens"] * fictional_input_units + usage["output_tokens"] * fictional_output_units
latency_ms = usage["retrieval_ms"] + usage["generation_ms"]
assert cost_units == 1950 and latency_ms == 730


baseline = {"supported_rate": 0.90, "p95_ms": 1500, "access_violations": 0}
candidate = {"supported_rate": 0.93, "p95_ms": 1400, "access_violations": 0}
release_allowed = (
    candidate["supported_rate"] >= baseline["supported_rate"]
    and candidate["p95_ms"] <= 1600
    and candidate["access_violations"] == 0
)
assert release_allowed

