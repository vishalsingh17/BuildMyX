# BuildMyX Generative AI: Build a retrieval-augmented generation pipeline
# Original CPU teaching example; run with Python 3.12+.

words = "Python functions take inputs and return values while classes group behavior".split()
size, overlap = 5, 1
assert size > overlap >= 0
chunks = [words[start:start + size] for start in range(0, len(words), size - overlap)]
assert chunks[0][-1] == chunks[1][0]
assert all(len(chunk) <= size for chunk in chunks)


records = [
    {"id": "public-1", "role": "public", "text": "Python functions"},
    {"id": "staff-1", "role": "staff", "text": "Private staff arrangements"},
]
reader_role = "public"
permitted = [record for record in records if record["role"] == "public" or reader_role == "staff"]
assert [record["id"] for record in permitted] == ["public-1"]

