# BuildMyX Generative AI: Predict a world and plan within it
# Original CPU teaching example; run with Python 3.12+.

true_state, predicted_state = 0.0, 0.0
actions = [1.0] * 5
for action in actions:
    true_state += action
    predicted_state += 0.9 * action
assert true_state == 5.0
assert abs(true_state - predicted_state - 0.5) < 1e-12

