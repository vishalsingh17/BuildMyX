# BuildMyX Generative AI: Transfer behavior with knowledge distillation
# Original CPU teaching example; run with Python 3.12+.

import math

def softmax(values, temperature):
    values = [value / temperature for value in values]
    weights = [math.exp(value - max(values)) for value in values]
    return [value / sum(weights) for value in weights]

def kl(teacher, student):
    return sum(p * math.log(p / q) for p, q in zip(teacher, student) if p > 0)

teacher = softmax([4.0, 2.0, 0.0], 2.0)
student = softmax([3.0, 2.0, 1.0], 2.0)
assert math.isclose(kl(teacher, teacher), 0.0, abs_tol=1e-12)
assert kl(teacher, student) > 0
assert teacher[0] < softmax([4.0, 2.0, 0.0], 1.0)[0]

