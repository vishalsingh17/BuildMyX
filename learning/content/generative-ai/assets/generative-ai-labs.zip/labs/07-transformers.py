# BuildMyX Generative AI: Assemble a transformer
# Original CPU teaching example; run with Python 3.12+.

import math

representations = [[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]]
result = []
for position, query in enumerate(representations):
    visible = representations[:position + 1]
    scores = [sum(q*k for q, k in zip(query, key)) / math.sqrt(2) for key in visible]
    shifted = [math.exp(score - max(scores)) for score in scores]
    weights = [value / sum(shifted) for value in shifted]
    mixed = [sum(weight * row[column] for weight, row in zip(weights, visible)) for column in range(2)]
    residual = [value + update for value, update in zip(query, mixed)]
    transformed = [max(0.0, value * 0.1) for value in residual]
    result.append([value + update for value, update in zip(residual, transformed)])
assert len(result) == 3 and all(len(row) == 2 for row in result)
assert result[0] == [2.2, 0.0]

