# BuildMyX Generative AI: Project: a grounded workshop assistant
# Original CPU teaching example; run with Python 3.12+.

from dataclasses import dataclass
import re

@dataclass(frozen=True)
class Document:
    id: str
    text: str
    access: str = "public"

corpus = [
    Document("python-1", "The fictional Python workshop covers functions and dictionaries."),
    Document("data-1", "The fictional data workshop uses tables and joins."),
    Document("staff-1", "Private discount arrangements are for staff only.", "staff"),
]

def terms(text):
    return set(re.findall(r"[a-z0-9]+", text.lower()))

def answer(question, role="public"):
    permitted = [doc for doc in corpus if doc.access == "public" or role == "staff"]
    scored = [(len(terms(question) & terms(doc.text)), doc) for doc in permitted]
    scored.sort(key=lambda pair: (-pair[0], pair[1].id))
    if not scored or scored[0][0] == 0:
        return {"status": "needs_information", "answer": "No matching evidence in this collection.", "citations": []}
    selected = scored[0][1]
    return {"status": "answered", "answer": selected.text, "citations": [selected.id]}

result = answer("Python functions")
assert result["status"] == "answered" and result["citations"] == ["python-1"]
assert answer("gardening")["status"] == "needs_information"
assert answer("private discount")["citations"] == []
assert answer("private discount", role="staff")["citations"] == ["staff-1"]

