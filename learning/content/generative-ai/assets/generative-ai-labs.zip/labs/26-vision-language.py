# BuildMyX Generative AI: Connect images and language
# Original CPU teaching example; run with Python 3.12+.

images = {"image-A": [1.0, 0.0], "image-B": [0.0, 1.0]}
labels = {"a diagram": [0.9, 0.1], "a garden": [0.1, 0.9]}

def score(left, right):
    return sum(x*y for x, y in zip(left, right))

ranking = sorted(labels, key=lambda label: score(images["image-A"], labels[label]), reverse=True)
assert ranking[0] == "a diagram"
assert score(images["image-A"], labels["a diagram"]) > score(images["image-A"], labels["a garden"])

