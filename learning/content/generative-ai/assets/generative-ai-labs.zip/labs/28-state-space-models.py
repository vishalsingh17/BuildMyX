# BuildMyX Generative AI: Model sequences with a state-space model
# Original CPU teaching example; run with Python 3.12+.

inputs = [2.0, 2.0, 1.0]
state, recurrent = 0.0, []
for value in inputs:
    state = 0.5 * state + value
    recurrent.append(state)
convolution = [sum((0.5 ** (time - index)) * inputs[index] for index in range(time + 1)) for time in range(len(inputs))]
assert recurrent == [2.0, 3.0, 2.5]
assert recurrent == convolution


state = 0.0
for value in [1.0, 0.0, 3.0]:
    retention = 0.2 if value > 2 else 0.8
    state = retention * state + value
assert abs(state - 3.16) < 1e-12

