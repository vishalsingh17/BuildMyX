# BuildMyX Generative AI: Design a bounded agent loop
# Original CPU teaching example; run with Python 3.12+.

observed_quality = [0.2, 0.6, 0.6, 0.6, 0.9]
maximum_steps, no_progress_limit = 4, 2
best, stagnant, status, used = -1.0, 0, "running", 0
for score in observed_quality[:maximum_steps]:
    used += 1
    if score > best:
        best, stagnant = score, 0
    else:
        stagnant += 1
    if score >= 0.85:
        status = "completed"
        break
    if stagnant >= no_progress_limit:
        status = "stalled"
        break
else:
    status = "budget_exhausted"
assert status == "stalled" and used == 4 and best == 0.6

