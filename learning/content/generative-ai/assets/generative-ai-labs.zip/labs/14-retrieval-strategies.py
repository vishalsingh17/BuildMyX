# BuildMyX Generative AI: Improve retrieval and choose a RAG design
# Original CPU teaching example; run with Python 3.12+.

lexical = ["python-1", "schedule-1", "data-1"]
semantic = ["data-1", "python-1", "support-1"]
scores = {}
for ranking in [lexical, semantic]:
    for rank, document_id in enumerate(ranking, 1):
        scores[document_id] = scores.get(document_id, 0.0) + 1 / (60 + rank)
fused = sorted(scores, key=scores.get, reverse=True)
assert fused[0] == "python-1"
assert set(fused) == set(lexical) | set(semantic)

