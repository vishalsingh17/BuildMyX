# BuildMyX Generative AI: Learn to reverse a noising process
# Original CPU teaching example; run with Python 3.12+.

import math
import random

rng = random.Random(12)
x0, alpha_bar = 1.5, 0.36
noise = rng.gauss(0.0, 1.0)
xt = math.sqrt(alpha_bar) * x0 + math.sqrt(1 - alpha_bar) * noise
# An oracle knows the exact sampled noise; a learned denoiser must estimate it.
reconstructed = (xt - math.sqrt(1 - alpha_bar) * noise) / math.sqrt(alpha_bar)
assert math.isclose(reconstructed, x0)
wrong_estimate = noise + 0.2
wrong_x0 = (xt - math.sqrt(1 - alpha_bar) * wrong_estimate) / math.sqrt(alpha_bar)
assert not math.isclose(wrong_x0, x0)

