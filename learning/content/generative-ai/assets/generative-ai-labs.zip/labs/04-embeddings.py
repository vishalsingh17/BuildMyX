# BuildMyX Generative AI: Represent meaning with embeddings
# Original CPU teaching example; run with Python 3.12+.

import math

def cosine(left, right):
    assert len(left) == len(right)
    lengths = math.sqrt(sum(x*x for x in left)) * math.sqrt(sum(x*x for x in right))
    if lengths == 0:
        raise ValueError("A zero vector has no cosine direction")
    return sum(x*y for x, y in zip(left, right)) / lengths

query = [1.0, 0.0, 1.0]
documents = {"python": [2.0, 0.0, 2.0], "gardening": [0.0, 1.0, 0.0]}
ranked = sorted(documents, key=lambda name: cosine(query, documents[name]), reverse=True)
assert ranked[0] == "python"
assert math.isclose(cosine(query, documents["python"]), 1.0)

