# BuildMyX Generative AI: Multi-head attention and efficient inference
# Original CPU teaching example; run with Python 3.12+.

# Cache storage estimate, excluding metadata, alignment and temporary buffers.
layers, batch, tokens, head_dimension, bytes_per_value = 24, 1, 2048, 64, 2
query_heads, grouped_kv_heads = 16, 4

def cache_bytes(kv_heads):
    return 2 * layers * batch * tokens * kv_heads * head_dimension * bytes_per_value

multi_head = cache_bytes(query_heads)
grouped_query = cache_bytes(grouped_kv_heads)
assert multi_head == 4 * grouped_query
assert cache_bytes(1) < grouped_query

