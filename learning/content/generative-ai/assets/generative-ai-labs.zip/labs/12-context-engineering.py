# BuildMyX Generative AI: Engineer the context
# Original CPU teaching example; run with Python 3.12+.

candidates = [
    {"id": "python-1", "tokens": 90, "score": 0.95},
    {"id": "schedule-1", "tokens": 80, "score": 0.90},
    {"id": "history-1", "tokens": 200, "score": 0.20},
]
budget, selected, used = 200, [], 0
for record in sorted(candidates, key=lambda record: record["score"], reverse=True):
    if used + record["tokens"] <= budget:
        selected.append(record["id"])
        used += record["tokens"]
assert selected == ["python-1", "schedule-1"]
assert used <= budget

