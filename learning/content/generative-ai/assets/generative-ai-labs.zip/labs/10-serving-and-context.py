# BuildMyX Generative AI: Serve a model and manage long context
# Original CPU teaching example; run with Python 3.12+.

layers, sequence, kv_heads, head_dimension, bytes_per_value = 24, 4096, 4, 64, 2
kv_bytes = 2 * layers * sequence * kv_heads * head_dimension * bytes_per_value
assert kv_bytes == 100663296  # 96 MiB for this single-sequence cache estimate
short_length, long_length = 2048, 4096
assert long_length**2 == 4 * short_length**2
assert long_length == 2 * short_length


window = 8192
instructions, question, tool_schema, output_reserve = 600, 150, 450, 1000
available_evidence = window - instructions - question - tool_schema - output_reserve
assert available_evidence == 5992
assert available_evidence > 0

