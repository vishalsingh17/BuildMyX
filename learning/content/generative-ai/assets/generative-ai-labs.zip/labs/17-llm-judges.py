# BuildMyX Generative AI: Evaluate with a calibrated LLM judge
# Original CPU teaching example; run with Python 3.12+.

observations = [
    {"order": ["A", "B"], "winner": "A"},
    {"order": ["B", "A"], "winner": "B"},
]
first_position_wins = sum(row["winner"] == row["order"][0] for row in observations)
consistent_candidate = len({row["winner"] for row in observations}) == 1
assert first_position_wins == 2
assert consistent_candidate is False


human = [True, True, False, False]
judge = [True, False, False, False]
agreement = sum(left == right for left, right in zip(human, judge)) / len(human)
false_accepts = sum(predicted and not actual for actual, predicted in zip(human, judge))
false_rejects = sum(actual and not predicted for actual, predicted in zip(human, judge))
assert agreement == 0.75 and false_accepts == 0 and false_rejects == 1

