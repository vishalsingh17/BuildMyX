# BuildMyX Generative AI: Write instructions and validate outputs
# Original CPU teaching example; run with Python 3.12+.

import json

allowed_ids = {"schedule-1", "python-1"}
raw = '{"answer":"The Python session includes functions.","citations":["python-1"],"status":"answered"}'
response = json.loads(raw)
assert set(response) == {"answer", "citations", "status"}
assert isinstance(response["answer"], str)
assert response["status"] in {"answered", "needs_information"}
assert isinstance(response["citations"], list)
assert all(isinstance(value, str) and value in allowed_ids for value in response["citations"])
assert response["status"] != "answered" or bool(response["citations"])

