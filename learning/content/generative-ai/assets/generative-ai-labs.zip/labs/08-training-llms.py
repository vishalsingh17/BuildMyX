# BuildMyX Generative AI: How language models are trained
# Original CPU teaching example; run with Python 3.12+.

import math

correct_token_probabilities = [0.8, 0.5, 0.25]
loss = -sum(math.log(value) for value in correct_token_probabilities) / 3
perplexity = math.exp(loss)
assert loss > 0 and perplexity > 1
better_probabilities = [0.9, 0.7, 0.5]
better_loss = -sum(math.log(value) for value in better_probabilities) / 3
assert better_loss < loss


training_documents = {"workshop-001", "workshop-002"}
validation_documents = {"workshop-003"}
test_documents = {"workshop-004"}
assert training_documents.isdisjoint(validation_documents)
assert training_documents.isdisjoint(test_documents)
assert validation_documents.isdisjoint(test_documents)

