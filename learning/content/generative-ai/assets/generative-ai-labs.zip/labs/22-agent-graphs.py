# BuildMyX Generative AI: Connect work with a reliable graph
# Original CPU teaching example; run with Python 3.12+.

required = {"retrieve", "policy_check"}
results = {}

def accept_result(task_id, value):
    if task_id in results and results[task_id] != value:
        raise ValueError("Conflicting replay requires reconciliation")
    results[task_id] = value

accept_result("retrieve", {"documents": ["python-1"]})
assert not required.issubset(results)
accept_result("policy_check", {"allowed": True})
accept_result("retrieve", {"documents": ["python-1"]})
assert required.issubset(results) and len(results) == 2

