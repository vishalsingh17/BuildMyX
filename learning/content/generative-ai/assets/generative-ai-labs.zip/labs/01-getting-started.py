# BuildMyX Generative AI: Start learning Generative AI
# Original CPU teaching example; run with Python 3.12+.

contract = {
    "task": "answer workshop questions using approved documents",
    "inputs": ["question", "reader_role"],
    "outputs": ["answer", "citations", "status"],
    "success": "supported answer or an explicit abstention",
}
assert "citations" in contract["outputs"]
assert contract["success"].endswith("explicit abstention")

