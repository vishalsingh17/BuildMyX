# BuildMyX Generative AI: Generate the next token
# Original CPU teaching example; run with Python 3.12+.

import math
import random

def distribution(logits, temperature=1.0):
    if temperature <= 0:
        raise ValueError("Use an explicit greedy branch for temperature zero")
    scaled = [value / temperature for value in logits]
    values = [math.exp(value - max(scaled)) for value in scaled]
    return [value / sum(values) for value in values]

cold = distribution([3.0, 2.0, 0.0], 0.5)
warm = distribution([3.0, 2.0, 0.0], 2.0)
assert cold[0] > warm[0]


probabilities = distribution([3.0, 2.0, 0.0])
ranked = sorted(range(len(probabilities)), key=probabilities.__getitem__, reverse=True)
selected, cumulative = [], 0.0
for index in ranked:
    selected.append(index)
    cumulative += probabilities[index]
    if cumulative >= 0.9:
        break
rng = random.Random(7)
chosen = rng.choices(selected, weights=[probabilities[index] for index in selected], k=1)[0]
assert chosen in selected
assert cumulative >= 0.9

